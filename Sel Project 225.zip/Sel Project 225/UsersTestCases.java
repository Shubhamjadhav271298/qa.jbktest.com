package DynamicXpath;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class UsersTestCases {
	@Test
	   public void chechCourses(){
		   System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		   WebDriver driver = new ChromeDriver();
		   driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/users.html");
		   
			  ArrayList<String>actlistCourse = new ArrayList<String>();

		  for(int i=2 ; i<6; i++){  
		  String courseAct = driver.findElement(By.xpath("//tr["+i+"]/td[5]")).getText();
		 
		  actlistCourse.add(courseAct);
		  }
		  ArrayList<String>expCourselist = new ArrayList<String>();
		  expCourselist.add("Java/J2EE");
		  expCourselist.add("Selenium");
		  expCourselist.add("Python");
		  expCourselist.add("PHP");
		  //// JDBC //// fetcl all courses from DB -- match 
		  Assert.assertEquals(actlistCourse, expCourselist);
	   }
	@Test
	public void chechUsers(){
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		   WebDriver driver = new ChromeDriver();
		   driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/users.html");
		   
		   ArrayList<String>actlist = new ArrayList<String>();
		   for(int i=2;i<9;i++){
			   String useract = driver.findElement(By.xpath("//tr[1]/th["+i+"]")).getText();
			   actlist.add(useract);   
		   }
		   ArrayList<String>explist = new ArrayList<String>();
		      explist.add("Username");
			  explist.add("Email");
			  explist.add("Mobile");
			  explist.add("Course");
			  explist.add("Gender");
			  explist.add("State");
			  explist.add("Action");
			
			Assert.assertEquals(actlist, explist);  
	}
	@Test
	public  void chechUsername(){
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/users.html");
		   
		ArrayList<String>actusername = new ArrayList<String>();
		for(int i=2;i<6;i++){
			String nameact = driver.findElement(By.xpath("//tr["+i+"]/td[2]")).getText();
			actusername.add(nameact);
		}
		ArrayList<String>expname = new ArrayList<String>();
		expname.add("Kiran");
		expname.add("Sagar");
		expname.add("Monica");
		expname.add("Kimaya");
		
		Assert.assertEquals(actusername, expname);
		
	}
	@Test
	public void chechmobile(){
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/users.html");
		
		ArrayList<String>actmobilelist = new ArrayList<String>();
		for(int i=2;i<6;i++){
			String actmobile = driver.findElement(By.xpath("//tbody/tr["+i+"]/td[4]")).getText();
			actmobilelist.add(actmobile);
		}
		ArrayList<String> expmobile = new ArrayList<String>();
		expmobile.add("9898989898");
		expmobile.add("999999999");
		expmobile.add("1111111111");
		expmobile.add("999999999");
		
		Assert.assertEquals(actmobilelist, expmobile);
	}
	@Test
	public void chechGender(){
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/users.html");
		
		ArrayList<String> actgenderlist = new ArrayList<String>();
		for(int i=2;i<6;i++){
			String actgander = driver.findElement(By.xpath("//tbody/tr["+i+"]/td[6]")).getText();
			actgenderlist.add(actgander);
		}
		ArrayList<String> expgender = new ArrayList<String>();
		expgender.add("Male");
		expgender.add("Male");
		expgender.add("Female1");
		expgender.add("Female");
		
		Assert.assertEquals(actgenderlist, expgender);
	}
	@Test
	public void chechEmail(){
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/users.html");
		
		ArrayList<String> actemail = new ArrayList<String>();
		for(int i=2;i<6;i++){
			String actmail = driver.findElement(By.xpath("//tr["+i+"]/td[3]")).getText();
			actemail.add(actmail);
		}
		ArrayList<String> expemail = new ArrayList<String>();
		expemail.add("kiran@gmail.com");
		expemail.add("sagar@javabykiran.com");
		expemail.add("monica@gmail.com");
		expemail.add("kimaya@gmail.com");
		
		Assert.assertEquals(actemail, expemail);
	}
	@Test
	public void chechState(){
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/users.html");
		
		ArrayList<String> actstatelist = new ArrayList<String>();
		for(int i=2;i<6;i++){
			String actstate = driver.findElement(By.xpath("//tr["+i+"]/td[7]")).getText();
			actstatelist.add(actstate);
		}
	    ArrayList<String> expstate = new ArrayList<String>();
	    expstate.add("Maharashtra");
	    expstate.add("Punjab");
	    expstate.add("Maharashtra");
	    expstate.add("Punjab");
	    
	    Assert.assertEquals(actstatelist,expstate);
	}
	@Test
	public void chechNumber(){
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/users.html");
		
		ArrayList<String> actlistno = new ArrayList<String>();
		for(int i=2;i<6;i++){
			String actlist = driver.findElement(By.xpath("//tr["+i+"]/td[1]")).getText();
			actlistno.add(actlist);
		}
		ArrayList<String> exlist = new ArrayList<String>();
		exlist.add("1");
		exlist.add("2");
		exlist.add("3");
		exlist.add("4");
	}
	@Test
	public void chechAddUser(){
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/users.html");
		
		driver.findElement(By.xpath("//div[1]/a/button")).click();
		//Username
		driver.findElement(By.xpath("//*[@id='username']")).sendKeys("Shubham Jadhav");
		//Mobile
		driver.findElement(By.xpath("//*[@id='mobile']")).sendKeys("9130843801");
		//Email
		driver.findElement(By.xpath("//*[@id='email']")).sendKeys("shubham@gmail.com");
		//Courses
		driver.findElement(By.xpath("//*[@id='course']")).sendKeys("Java/J2EE");
		//Gender
		driver.findElement(By.xpath("//*[@id='Male']")).click();
		//State
		driver.findElement(By.xpath("//div/select")).sendKeys("Maharashtra");
		//Password
		driver.findElement(By.xpath("//*[@id='password']")).sendKeys("123456789");
		//Friend Mobile
		driver.findElement(By.xpath("//form/div[3]/div/input")).sendKeys("1234567890");
		//submit
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		
	}
}
