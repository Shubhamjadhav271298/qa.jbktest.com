package DynamicXpath;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class OperatorsTestCases {
  @Test
  public void chechOperator(){
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	   WebDriver driver = new ChromeDriver();
	   driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/operators.html");
	   
	   ArrayList<String> actlist = new ArrayList<String>();
       for(int i=1;i<7;i++){
    	   String actOperator = driver.findElement(By.xpath("//tr[1]/th["+i+"]")).getText();
    	   actlist.add(actOperator);
       }
       ArrayList<String> explist = new ArrayList<String>();
       explist.add("ID");
       explist.add("Person");
       explist.add("For");
       explist.add("Prefered Way to Connect");
       explist.add("Contact");
       explist.add("Timings");
       
       Assert.assertEquals(actlist, explist);   
  }
  @Test
  public void chechID(){
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	   WebDriver driver = new ChromeDriver();
	   driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/operators.html");
	   
	   ArrayList<String> actidlist = new ArrayList<String>();
	   for(int i=2;i<7;i++){
		   String actlistid = driver.findElement(By.xpath("//tr["+i+"]/td[1]")).getText();
		   actidlist.add(actlistid);
	   }
	   ArrayList<String> expidlist = new ArrayList<String>();
	   expidlist.add("01");
	   expidlist.add("02");
	   expidlist.add("03");
	   expidlist.add("04");
	   expidlist.add("05");
  }   
  @Test
  public void chechPerson(){
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	   WebDriver driver = new ChromeDriver();
	   driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/operators.html");
	   
	   ArrayList<String> actname = new ArrayList<String>();
	   for(int i=2;i<7;i++){
		   String actperson = driver.findElement(By.xpath("//tr["+i+"]/td[2]")).getText();
		   actname.add(actperson);
	   }
	   ArrayList<String> expname = new ArrayList<String>();
	   expname.add("Kiran");
	   expname.add("Neelam");
	   expname.add("Seema");
	   expname.add("Varsha");
	   expname.add("Darshit");
	   
	   Assert.assertEquals(actname, expname);
  }
  @Test
  public void chechFor(){
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	   WebDriver driver = new ChromeDriver();
	   driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/operators.html");
	   
	   ArrayList<String> actforlist = new ArrayList<String>();
	   for(int i=2;i<7;i++){
		   String actfor = driver.findElement(By.xpath("//tr["+i+"]/td[3]")).getText();
		   actforlist.add(actfor);
	   }
	   ArrayList<String> expfor = new ArrayList<String>();
	   expfor.add("Urgent Technical Help");
	   expfor.add("Technical Discussion (Errors, Software, Technical Materials)");
	   expfor.add("Administration (Fees, ID Card, Certificates, WhatsApp Group, Enquiry)");
	   expfor.add("Enquiry(Course Details, Fees, Enquiry)");
	   expfor.add("Technical Help");
	   
	   Assert.assertEquals(actforlist, expfor);
  }
  @Test
  public void chechContact(){
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	   WebDriver driver = new ChromeDriver();
	   driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/operators.html");
	   
	   ArrayList<String> actContactlist = new ArrayList<String>();
	   for(int i=2;i<7;i++){
		   String actContact = driver.findElement(By.xpath("//tr["+i+"]/td[5]")).getText();
		   actContactlist.add(actContact);
	   }
	   ArrayList<String> expContactlist = new ArrayList<String>();
	   expContactlist.add("9552343698");
	   expContactlist.add("7066885937");
	   expContactlist.add("8888558802");
	   expContactlist.add("8888809416");
	   expContactlist.add("8866888662");
	   
	   Assert.assertEquals(actContactlist, expContactlist);
  }
  @Test
  public void chechTimings(){
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	   WebDriver driver = new ChromeDriver();
	   driver.get("file:///C:/Users/user/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/operators.html");
	   
	   ArrayList<String> actTimingslist = new ArrayList<String>();
	   for(int i=2;i<7;i++){
		   String actTimings = driver.findElement(By.xpath("//tr["+i+"]/td[6]/b")).getText();
		   actTimingslist.add(actTimings);
	   }
	   ArrayList<String> expTimingslist = new ArrayList<String>();
	   expTimingslist.add("Monday-Sunday");
	   expTimingslist.add("Monday-Saturday");
	   expTimingslist.add("Monday-Saturday");
	   expTimingslist.add("Monday to Friday and Sunday");
	   expTimingslist.add("Saturday-Sunday");
	   
	   Assert.assertEquals(actTimingslist, expTimingslist);
 }
}