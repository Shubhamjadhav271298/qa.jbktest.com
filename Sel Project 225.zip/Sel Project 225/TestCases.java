package Project;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestCases {
	// 1
	@Test
	public void checkLogin() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		String val = driver.findElement(By.name("count")).getAttribute("value");
		System.out.println(val);
		// Manual Testing(ISTQB)
		driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
		// Next click
		driver.findElement(By.id("countbtn")).click();
		// mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843802");
		// login btn
		driver.findElement(By.id("loginbtn")).click();

		String explogin = "Enter your Mobile Number";
		String actlogin = driver.findElement(By.xpath("//*[@id='quizlogin']/div[1]/div[1]/label")).getText();
		Assert.assertEquals(actlogin, explogin);
	}

	// 2
	@Test
	public void checkExamFunt() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();

		String val = driver.findElement(By.name("count")).getAttribute("value");
		System.out.println(val);
		// count no 10
		driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[1]")).click();
		// next btn
		driver.findElement(By.id("countbtn")).click();
		// mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9511861977");
		// login btn
		driver.findElement(By.id("loginbtn")).click();

		int num = Integer.parseInt(val);
		for (int i = 1; i <= num - 1; i++) {
			// Next << btn
			WebElement ele = driver.findElement(By.xpath("//*[@id=\"quizsection\"]/div[2]/a[1]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);
		}
		// Submit btn
		WebElement ele = driver.findElement(By.id("qsubmit"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);

		String expresult = "Your Result";
		String actresult = driver.findElement(By.xpath("//*[text()='Your Result']")).getText();

		Assert.assertEquals(actresult, expresult);
	}

	// 3
	@Test
	public void checkUpdateFun() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		// next btn
		driver.findElement(By.xpath("//*[@id='countbtn']")).click();
		// enter mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();
		// myaccount
		driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		// View Profile
		driver.findElement(By.xpath("//div[6]/div/div/div/div[1]/div/a")).click();
		driver.findElement(By.id("name")).click();
		driver.findElement(By.id("emailid")).click();
		driver.findElement(By.id("mobile")).click();

		driver.findElement(By.id("mobile")).sendKeys("Shubham Jadhav");
		driver.findElement(By.id("emailid")).sendKeys("shubhamjadhav@gamil.com");
		driver.findElement(By.id("mobile")).sendKeys("9130843801");
		// update
		driver.findElement(By.id("updatebtn")).click();

		String expupdatemsg = "Profile successfully updated";
		String actupdatemsg = driver.findElement(By.xpath("//*[text()='Profile successfully updated']")).getText();

		Assert.assertEquals(actupdatemsg, expupdatemsg);
	}

	// 4
	@Test
	public void checkExamFunt20() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		// url
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		// count
		String val = driver.findElement(By.name("count")).getAttribute("value");
		System.out.println(val);
		// count no 20
		driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[2]")).click();
		// next btn
		driver.findElement(By.id("countbtn")).click();
		// mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9511861977");
		// login btn
		driver.findElement(By.id("loginbtn")).click();

		int num = Integer.parseInt(val);
		for (int i = 1; i <= num - 1; i++) {
			// Next << btn
			WebElement ele = driver.findElement(By.xpath("//*[@id=\"quizsection\"]/div[2]/a[1]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);
		}
		// Submit btn
		WebElement ele = driver.findElement(By.id("qsubmit"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);

		String expresult = "Your Result";
		String actresult = driver.findElement(By.xpath("//*[text()='Your Result']")).getText();

		Assert.assertEquals(actresult, expresult);
	}

	// 5
	@Test
	public void checkExamFunt25() {
		System.setProperty("webdriver.chrome.drivere", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		// url
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//*[@id='Testing']/div/div[1]/a/div")).click();
		// count
		String val = driver.findElement(By.name("count")).getAttribute("value");
		System.out.println(val);
		// count no 25
		driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[3]")).click();
		// next btn
		driver.findElement(By.id("countbtn")).click();
		// mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();

		int num = Integer.parseInt(val);
		for (int i = 1; i <= num - 1; i++) {
			// Next << btn
			WebElement ele = driver.findElement(By.xpath("//*[text()='Next �']"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);
		}
		// submit btn
		WebElement ele = driver.findElement(By.id("qsubmit"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);

		String expresult = "Your Result";
		String actresult = driver.findElement(By.xpath("//*[text()='Your Result']")).getText();

		Assert.assertEquals(actresult, expresult);
	}

	// 6
	@Test
	public void checkSignUp() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);
		// Manual Testing(ISTQB)
		driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
		// Next click
		driver.findElement(By.id("countbtn")).click();
		// mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843802");
		// login btn
		driver.findElement(By.id("loginbtn")).click();
		// singup
		driver.findElement(By.id("signup-tab")).click();
		// name
		driver.findElement(By.id("name")).sendKeys("Shubham Jadhav");
		// email id
		driver.findElement(By.id("emailid")).sendKeys("shubhajadhav@gmail.com");
		// mobile no
		driver.findElement(By.id("mobile")).sendKeys("9511861978");

		action.sendKeys(Keys.TAB).perform();

		driver.findElement(By.id("agree")).click();
		driver.findElement(By.id("emailbtn")).click();

		String expmsg = "Sign Up";
		String actmsg = driver.findElement(By.xpath("//*[@id='signup-tab']")).getText();

		Assert.assertEquals(actmsg, expmsg);
	}

	// 7
	@Test
	public void checkFailed_Attempt() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		// next btn
		driver.findElement(By.xpath("//*[@id='countbtn']")).click();
		// enter mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();
		// myaccount
		driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		// Failed Attempt
		driver.findElement(By.xpath("//div[3]/div/div/div/div[1]/div/a")).click();

		String expattempt = "Failed Attempt";
		String actattempt = driver.findElement(By.xpath("//div[1]/h4")).getText();

		Assert.assertEquals(actattempt, expattempt);
	}

	// 8
	@Test
	public void checkChech_View_Answer() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();

		String val = driver.findElement(By.name("count")).getAttribute("value");
		System.out.println(val);

		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("9511861977");
		driver.findElement(By.id("loginbtn")).click();

		int num = Integer.parseInt(val);
		for (int i = 1; i <= num - 1; i++) {
			WebElement ele = driver.findElement(By.xpath("//*[@id=\"quizsection\"]/div[2]/a[1]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);
		}
		WebElement ele = driver.findElement(By.id("qsubmit"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);
		// View Answer
		driver.findElement(By.xpath("//*[@id='quizresult']/div[2]")).click();

		String expanswer = "Check Your Answers";
		String actanswer = driver.findElement(By.xpath("//*[text()='Check Your Answers']")).getText();

		Assert.assertEquals(actanswer, expanswer);
	}

	// 9
	@Test
	public void checkTest_Attempted() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		// next btn
		driver.findElement(By.xpath("//*[@id='countbtn']")).click();
		// enter mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();
		// myaccount
		driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		// Test Attempted
		driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div/div/div/div[1]/div/a")).click();

		String expattempted = "Test Attempted";
		String actattempted = driver.findElement(By.xpath("//div[1]/h4")).getText();

		Assert.assertEquals(actattempted, expattempted);
	}

	// 10
	@Test

	public void checkTimeline() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		// next btn
		driver.findElement(By.xpath("//*[@id='countbtn']")).click();
		// enter mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();
		// myaccount
		driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		// Timeline
		driver.findElement(By.xpath("//div[4]/div/div/div/div[1]/div/a")).click();

		String expchart = "Timeline";
		String actchart = driver.findElement(By.xpath("//*[@id=chartContainer]/div/canvas[2]")).getText();

		Assert.assertEquals(actchart, expchart);
	}

	// 11
	@Test

	public void checkTotal_Topics_Covered() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		// next btn
		driver.findElement(By.xpath("//*[@id='countbtn']")).click();
		// enter mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();
		// myaccount
		driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		// Total Topics Covered
		driver.findElement(By.xpath("//div[5]/div/div/div/div[1]/div/a")).click();

		String exptopics = "Topics Covered";
		String acttopics = driver.findElement(By.xpath("//*[@id='chartContainer']/div/canvas[2]")).getText();

		Assert.assertEquals(acttopics, exptopics);
	}

	//12
	@Test
	public void checkYour_Good_Score() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		// next btn
		driver.findElement(By.xpath("//*[@id='countbtn']")).click();
		// enter mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();
		// myaccount
		driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		// Your Good Score
		driver.findElement(By.xpath("//div[2]/div/div/div/div[1]/div/a")).click();

		String expscore = "Good Score";
		String actscore = driver.findElement(By.xpath("//div[2]/div/div/h4")).getText();

		Assert.assertEquals(actscore, expscore);
	}

	//13
	@Test
	public void checkLogout() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		// next btn
		driver.findElement(By.xpath("//*[@id='countbtn']")).click();
		// enter mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();
		// myaccount
		driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		// Logout
		driver.findElement(By.xpath("//*[text()='Logout']")).click();

		String expexam = "Test";
		String actexam = driver.findElement(By.xpath("//div[2]/h1/a")).getText();

		Assert.assertEquals(actexam, expexam);
	}

	//14
	@Test
	public void checkContribute() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		// next btn
		driver.findElement(By.xpath("//*[@id='countbtn']")).click();
		// enter mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();
		// myaccount
		driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		// contribute
		driver.findElement(By.xpath("//*[@id='navbarResponsive']/div/a")).click();
		// full name
		driver.findElement(By.xpath("//div[1]/input")).sendKeys("shubham jadhav");
		// gmail
		driver.findElement(By.xpath("//div[2]/input")).sendKeys("shubham@mail.com");
		// Phone number
		driver.findElement(By.xpath("//*[@id='phone']")).sendKeys("9130843801");
		// contibuor
		driver.findElement(By.xpath("//*[@id='exampleFormControlSelect1']")).sendKeys("Contibutor");
		// submit
		driver.findElement(By.xpath("//form/button")).click();

		String expmsg = "Mail Sent. Thank you shubham jadhav, we will contact you shortly.";
		String actmsg = driver.findElement(By.xpath("//*[@id='mail_success']")).getText();

		Assert.assertEquals(actmsg, expmsg);
	}

	//15
	@Test
	public void checkPlacementQuiz1() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Placement-Policy");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Actions action = new Actions(driver);

		driver.findElement(By.xpath("//*[@id='Placement-Policy']/div/div/a/div")).click();

		String val = driver.findElement(By.name("count")).getAttribute("value");
		System.out.println(val);
		// next btn
		driver.findElement(By.xpath("//*[@id='countbtn']")).click();
		// enter mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();

		int num = Integer.parseInt(val);
		for (int i = 1; i <= num - 1; i++) {
			// Next << btn
			WebElement ele = driver.findElement(By.xpath("//*[@id=\"quizsection\"]/div[2]/a[1]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);
		}
		// Submit btn
		WebElement ele = driver.findElement(By.id("qsubmit"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);

		String expresult = "Sorry!!!";
		String actresult = driver.findElement(By.xpath("//*[@id='msg']/h3")).getText();

		Assert.assertEquals(actresult, expresult);
	}

	//16
	@Test
	public void checkTopice() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		Actions actions = new Actions(driver);

		driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		driver.findElement(By.id("loginbtn")).click();
		driver.findElement(By.xpath("//*[@id=\"myaccount\"]/a[1]")).click();
		driver.findElement(By.xpath(" /html/body/div[1]/div[1]/div[1]/div[2]/div/h1")).click();

		String expresult = "Dashboard";
		String actresult = driver.findElement(By.xpath("//div[2]/div[1]/div[1]/h4")).getText();

		Assert.assertEquals(actresult, expresult);
	}

	//17
	@Test
	public void checkExamTestt1() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#testtttt");

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		Actions actions = new Actions(driver);
		driver.manage().window().maximize();
		// test2
		driver.findElement(By.xpath("//*[@id='testtttt']/div/div[1]/a/div")).click();
		// next btn
		driver.findElement(By.id("countbtn")).click();
		// mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();

		String expresult = "Sorry!!! No Questions Found";
		String actresult = driver.findElement(By.xpath("//*[@id='noquestion']/h3")).getText();

		Assert.assertEquals(actresult, expresult);
	}

	//18
	@Test
	public void checkExamTestt2() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#testtttt");

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		Actions actions = new Actions(driver);
		driver.manage().window().maximize();
		// test2
		driver.findElement(By.xpath("//*[@id='testtttt']/div/div[2]/a/div")).click();

		String val = driver.findElement(By.name("count")).getAttribute("value");
		System.out.println(val);
		// next btn
		driver.findElement(By.id("countbtn")).click();
		// mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9130843801");
		// login btn
		driver.findElement(By.id("loginbtn")).click();

		int num = Integer.parseInt(val);
		for (int i = 1; i <= num - 1; i++) {
			// Next << btn
			WebElement ele = driver.findElement(By.xpath("//*[@id=\"quizsection\"]/div[2]/a[1]"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);
		}
		// Submit btn
		WebElement ele = driver.findElement(By.id("qsubmit"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);

		String expresult = "Your Result";
		String actresult = driver.findElement(By.xpath("//*[text()='Your Result']")).getText();

		Assert.assertEquals(actresult, expresult);
	}

	//19
	@Test
	public void checkSyllabus() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#testtttt");

		driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[2]/a")).click();

		String expmsg = "Syllabus";
		String actmsg = driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[2]/a")).getText();

		Assert.assertEquals(actmsg, expmsg);
	}

	//20
	@Test
	public void checkInterviewQuestion() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#testtttt");

		driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[3]/a")).click();

		String expmsg = "Interview Question";
		String actmsg = driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[3]/a")).getText();

		Assert.assertEquals(actmsg, expmsg);
	}

	//21
	@Test
	public void checkContactUs() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#testtttt");

		driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[4]/a")).click();

		String expmsg = "Contact Us";
		String actmsg = driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[4]/a")).getText();

		Assert.assertEquals(actmsg, expmsg);
	}

	// 22
	@Test
	public void checkLiveVideos() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#testtttt");

		driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[5]/a")).click();

		String expmsg = "Live Videos";
		String actmsg = driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[5]/a")).getText();

		Assert.assertEquals(actmsg, expmsg);
	}

	// 23
	@Test
	public void checkTutorials() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#testtttt");

		driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[6]/a")).click();

		String expmsg = "Tutorials";
		String actmsg = driver.findElement(By.xpath("//*[@id='navbarResponsive']/ul/li[6]/a")).getText();

		Assert.assertEquals(actmsg, expmsg);
	}
}
